<template>
  <i class="fas fa-comment-dots fa-3x chat-button"></i>
</template>

<script>
export default {
  name: "ChatButton",
};
</script>

<style scoped>
i.fas.fa-comment-dots.fa-3x.chat-button {
  position: fixed;
  top: 400px;
  color: green;
}
</style>