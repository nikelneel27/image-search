<template>
    <div class="headersecond">
        <ul class="links-second">
            <li>Editorial</li>
            <li>Following</li>
            <li>Summer on Film</li>
            <li>Wallpapers</li>
            <li>Nature</li>
            <li>Experimental</li>
            <li>People</li>
            <li>Architecture</li>
            <li>CurrentEvents</li>
            <li>Business & work</li>
            <li>View All</li>

        </ul>
    </div>
</template>

<script>
export default {};
</script>

<style>
.headerSecond{
    display: flex;
    
}
.links-second{
    margin-bottom: 20px;
}
</style>
